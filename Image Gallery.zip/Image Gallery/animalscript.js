const descriptions = {
    "Tiger": "Tiger – A powerful big cat known for its strength and distinctive orange-black stripes.",
    "Dog": "Dog – Loyal and friendly companions, often called man's best friend.",
    "Cat": "Cat – Graceful, curious pets loved for their independence and charm.",
    "Deer": "Deer – Gentle forest animals known for their speed and elegant antlers.",
    "Birds": "Birds – Colorful and diverse creatures that bring life to the skies.",
    "Lion": "Lion – The majestic 'king of the jungle' known for its power and pride.",
    "Snake": "Snake – Slithering reptiles that vary from harmless to venomous predators.",
    "Catfish": "Catfish – Freshwater fish named for their whisker-like barbels.",
    "Elephant": "Elephant – The largest land mammal, known for intelligence and long trunks.",
    "Zebra": "Zebra – African animals famous for their unique black and white stripes.",
    "Giraffe": "Giraffe – The tallest land animal, recognized by its long neck and legs.",
    "Cheetah": "Cheetah – The fastest land animal, built for high-speed chases.",
    "Horse": "Horse – Strong and swift, horses have served humans for centuries.",
    "Rabbit": "Rabbit – Small, furry animals with long ears and a gentle nature.",
    "Dolphin": "Dolphin – Intelligent and playful marine mammals known for their friendly behavior.",
    "Rhino": "Rhino – Large, thick-skinned animals with iconic horns, often endangered."
};

    // Create and style tooltip
    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    // Attach events to all images
    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });

