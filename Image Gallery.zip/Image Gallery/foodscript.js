const descriptions = {
    "Pizza": "Pizza - Cheesy, crusty favorite for all occasions.",
    "Burger": "Burger - Juicy layers stacked with flavor.",
    "Fries": "Fries - Crispy bites of potato perfection.",
    "Hotdog": "Hotdog - Classic street food in a bun.",
    "Pancake": "Pancake - Fluffy stacks drizzled with delight.",
    "Salad": "Salad - Fresh mix of greens and crunch.",
    "Spagethi": "Spaghetti - Twirled noodles in savory sauce.",
    "Tacos": "Tacos - Zesty fillings wrapped in crispy shells.",
    "Lasagna": "Lasagna - Rich layers of pasta and cheese.",
    "Steak": "Steak - Grilled excellence with bold taste.",
    "Chicken": "Roasted Chicken - Tender with smoky flavor.",
    "Noodles": "Noodles - Slurpy strands in spicy broth.",
    "Cup Cake": "Cupcake - Mini cakes with a sweet crown.",
    "Cake": "Cake - Layered indulgence for celebrations.",
    "Donuts": "Donuts - Fried rings glazed with joy.",
    "Ice Cream": "Ice Cream - Frozen scoops of happiness."
};

    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });

