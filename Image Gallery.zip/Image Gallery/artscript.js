const descriptions = {
    "Paint Brush": "A set of vibrant paint brushes ready for creating a masterpiece.",
    "Girl Making Art": "A young artist immersed in her creative world, painting passionately.",
    "Mona Lisa": "Leonardo da Vinci's famous masterpiece — the mysterious Mona Lisa.",
    "Abstract Painting": "A colorful and thought-provoking abstract painting filled with energy.",
    "Lion Mural": "A bold and powerful street mural of a lion, showcasing artistic strength.",
    "Old Village": "A serene painting of an old rustic village, evoking nostalgia and charm.",
    "Ocean Paint": "A tranquil painting of the ocean capturing waves and sky in motion.",
    "Tree paint": "An expressive piece portraying a lone tree in vibrant natural tones.",
    "Small Village by the lake": "A cozy lakeside village captured in peaceful, detailed brushwork.",
    "Tree by the wind": "A lone tree swaying in the wind — a symbol of resilience in nature.",
    "Old Guy Mural": "A mural of an elderly man, full of emotion and wisdom in its strokes.",
    "Bowling": "A sports mural depicting the energy and motion of a bowling strike.",
    "Maradona": "A tribute mural to football legend Diego Maradona, full of history and pride.",
    "Skating": "A dynamic mural of a skateboarder in action, filled with youthful spirit.",
    "Paint": "Vivid paint on canvas, blending colors and texture in a raw expression."
};

    // Create and style tooltip
    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    // Attach events to all images
    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });

