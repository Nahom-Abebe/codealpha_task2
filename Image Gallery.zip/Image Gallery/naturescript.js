const descriptions = {
    "Rocks": "Rock Formations - Rugged beauty carved by time.",
    "Sunrise": "Sunrise - A serene glow marking the day's beginning.",
    "Rainy Day": "Rainfall - Gentle showers painting the earth fresh.",
    "Great Wall of China": "Great Wall - Ancient might stretching through history.",
    "Sunset": "Sunset - A golden farewell to the day.",
    "Waterfall": "Waterfall - Nature’s powerful plunge into calm.",
    "Volcano": "Volcano - Majestic with simmering intensity.",
    "Hotair Balloon": "Hot Air Balloon - Floating wonder over scenic views.",
    "Foggy Mountain": "Foggy Peak - Mystical heights lost in cloud.",
    "Grass": "Grassland - Green stretches of tranquil softness.",
    "Flowers": "Bloom Field - A splash of color in open air.",
    "Beautiful Landscape": "Scenic Vista - Earth’s artistry on full display.",
    "Ocean": "Ocean - Endless blue and rhythmic waves.",
    "Jungle": "Jungle - Wild heart teeming with life.",
    "The Grand Canyon": "Grand Canyon - Majestic layers carved by time.",
    "Volcano Erruption": "Volcano Eruption - Fiery force shaping the land."
};
   
    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });

