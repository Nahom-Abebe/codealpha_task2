const descriptions = {
    "Box Building": "A modern cube-style structure with minimalist design and clean lines.",
    "Green View Building": "A sleek glass building surrounded by lush greenery, blending nature and urban design.",
    "Skyscrappers": "A cluster of towering skyscrapers symbolizing modern urban architecture.",
    "Red Cave": "An architectural structure carved into natural red rock, blending nature and shelter.",
    "Building in Dubai": "Futuristic high-rise architecture in the heart of Dubai’s skyline.",
    "Brown Glass Building": "A brown-tinted glass structure reflecting elegance and functionality.",
    "Burj Khalifa": "The tallest building in the world, located in Dubai — a marvel of engineering.",
    "Skyscraper": "A single towering skyscraper piercing the sky, symbolizing growth and ambition.",
    "Old castle": "A historic stone castle representing medieval architecture and heritage.",
    "Old building at night": "A charming old building beautifully lit at night with a nostalgic ambiance.",
    "Old City Building": "A traditional urban structure showcasing vintage city architecture.",
    "Old Church": "An ancient church with rich historical and architectural significance.",
    "Broken Building": "A decaying or ruined building capturing the beauty of abandonment and time.",
    "Building in Mountains": "A scenic architectural marvel nestled within mountain landscapes.",
    "Flower like building": "An artistic structure with floral design elements — where architecture meets sculpture.",
    "Tower of Pisa": "The Leaning Tower of Pisa — Italy’s famous architectural icon with a unique tilt."
};
  
    // Create and style tooltip
    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    // Attach events to all images
    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });