const descriptions = {
    "Ferrari": "Ferrari - Iconic Italian sports car known for speed and design.",
    "BMW": "BMW - German engineering with performance and luxury.",
    "Mercedes": "Mercedes-Benz - Luxury and innovation combined.",
    "Bugatti": "Bugatti - Ultra-luxury hypercars with incredible speed.",
    "Range Rover": "Range Rover - A blend of off-road power and luxury.",
    "Ford": "Ford - American legacy in mobility and innovation.",
    "Lamborghini": "Lamborghini - Bold, aggressive, and stylish supercars.",
    "Chevorlette": "Chevrolet - Trusted American cars with modern appeal.",
    "Jeep": "Jeep - Built for adventure and rugged terrain.",
    "Audi": "Audi - Progressive design and advanced technology.",
    "Porchse": "Porsche - Engineering excellence and timeless style.",
    "Old Car": "Vintage Classic - A piece of automotive history.",
    "Volkswagen": "Volkswagen - Reliable, efficient, and iconic.",
    "Old Cars": "Retro Beauties - A nostalgic look at classic designs.",
    "Tesla": "Tesla - Leading the electric revolution.",
    "Toyota": "Toyota - Practical, durable, and globally loved."
};

    // Create and style tooltip
    const tooltip = document.createElement("div");
    tooltip.style.position = "absolute";
    tooltip.style.background = "blue";
    tooltip.style.color = "#fff";
    tooltip.style.padding = "8px 12px";
    tooltip.style.borderRadius = "5px";
    tooltip.style.fontSize = "0.9rem";
    tooltip.style.zIndex = "1000";
    tooltip.style.display = "none";
    document.body.appendChild(tooltip);

    // Attach events to all images
    document.querySelectorAll("td img").forEach(img => {
        const altText = img.alt;

        img.addEventListener("mouseover", (e) => {
            tooltip.textContent = descriptions[altText] || "No description available";
            tooltip.style.display = "block";
        });

        img.addEventListener("mousemove", (e) => {
            tooltip.style.left = e.pageX + 15 + "px";
            tooltip.style.top = e.pageY + 15 + "px";
        });

        img.addEventListener("mouseout", () => {
            tooltip.style.display = "none";
        });
    });

